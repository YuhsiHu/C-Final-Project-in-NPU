#include <iostream>
#include<string.h>
#include<stdio.h>
#include <math.h>
#include <stdlib.h>
using namespace std;
int n;
struct STUDENT  //����ѧ���ɼ��ṹ��
{
    char name[15];
    int score;
}student[100];


void Quick(struct STUDENT b[],int l)//����������
{
  int i=0,j=l-1,val=b[0].score;
  char vall[15];
  strcpy(vall,b[0].name);
  if(l>1)
 {while(i<j)
	{
     for(;j>i;j--)
     if(b[j].score<val) {b[i].score=b[j].score;strcpy(b[i++].name,b[j].name);break;}

     for(;i<j;i++)
     if(b[i].score>val) {b[j].score=b[i].score;strcpy(b[j--].name,b[i].name);break;}
	}
   b[i].score=val;strcpy(b[i].name,vall);
   Quick(b,i);
   Quick(b+i+1,l-i-1);
  }
}

void Insert(STUDENT b[],int l)//����������
{
    int i,j,temp;
    char tem[15];
    for(i=1;i<l;i++)
     {
      temp=b[i].score;
      strcpy(tem,b[i].name);
      j=i-1;
      while(j>=0&&temp<b[j].score)
        {
         b[j+1].score=b[j].score;
         strcpy(b[j+1].name,b[j].name);
         j--;
        }
      b[j+1].score=temp;
      strcpy(b[j+1].name,tem);
    }
}

void Select(STUDENT b[],int l)//ѡ��������
{
 int i,j,k,temp;
 char mingzi[20];
 for(i=0;i<l-1;i++)
    {
     k=i; //���ǺŸ�ֵ
     for(j=i+1;j<l;j++)
     if(b[k].score>b[j].score) k=j; //��k����ָ����СԪ��
     if(i!=k)//��k!=iʱ�Ž���������a[i]��Ϊ��С
     {
      temp=b[i].score;strcpy(mingzi,b[i].name);
      b[i].score=b[k].score;strcpy(b[i].name,b[k].name);
      b[k].score=temp;strcpy(b[k].name,mingzi);
     }
    }
}


void Bubble(STUDENT b[],int l)//ð��������
{
  int i,j,temp;
  char mingzi[20]="\0";
  for(i=0;i<l-1;i++)
    for(j=i+1;j<l;j++)
    if(b[i].score>b[j].score)
    {
     temp=b[i].score;
     strcpy(mingzi,b[i].name);
     b[i].score=b[j].score;
     strcpy(b[i].name,b[j].name);
     b[j].score=temp;
     strcpy(b[j].name,mingzi);
    }
}

const int POT[8]={1,10,100,1000,10000,100000,1000000,10000000};//digit�Ǳ�ʾ�ɼ�����ж���λ��main��maxx���������
void Radix(int digit)	//����������
{
	int curDigit;
	int cSort[10];
	struct STUDENT tmpArr[1024];
	for (int k=0; k<digit; ++k)
	{
		memset(cSort,0,sizeof(cSort));
		memset(tmpArr,0,sizeof(tmpArr));
		for (int i=0;i<n;++i)
		{
			curDigit=(student[i].score/POT[k])%10;	//��ǰλ����
			++cSort[curDigit];
		}
		for (int i=1;i<10;++i)
			cSort[i] += cSort[i-1];
		for (int i=n-1; i>=0; --i)
		{
			curDigit = (student[i].score/POT[k]) % 10;	//��ǰλ����
			tmpArr[ --cSort[curDigit] ] = student[i];
		}
		for (int i=0; i<n; ++i)
			student[i]=tmpArr[i];
	}
}


int main()
{
    char choose[10];
    int i;
    cout<<"  "<<endl;
    cout << "********************Welcome to sort algorithm test system********************" << endl;
    cout<<"  "<<endl;
    cout<<"Please choose the sort method and enter:"<<endl;
    cout<<"Quick"<<endl;                                     //��������
    cout<<"Insert"<<endl;                                    //��������
    cout<<"Select"<<endl;                                    //ѡ������
    cout<<"Bubble"<<endl;                                    //ð������
    cout<<"Radix"<<endl;                                     //��������
    cout<<"  "<<endl;
    cin>>choose;
    cout<<"Please enter the total number of students:"<<endl;
    cin>>n;
    cout<<"Please enter students' names and grades:"<<endl;
    for (i=0;i<n;i++) cin>>student[i].name>>student[i].score;
    cout<<"  "<<endl;
    if (choose[0]=='Q') Quick(student,n);
    else if (choose[0]=='I') Insert(student,n);
    else if (choose[0]=='S') Select(student,n);
    else if (choose[0]=='B') Bubble(student,n);
    else if (choose[0]=='R')
     {
       int maxx=0;
       for(i=0;i<n;i++)
        {
         if (student[i].score>maxx)maxx=student[i].score;
        }
       Radix(maxx==0?0:(int)(log10(maxx)+1));
    }
    else cout<<"Wrong!"<<endl;

    for(i=0;i<n;i++)cout<<student[i].name<<" "<<student[i].score<<endl;
    return 0;
}
